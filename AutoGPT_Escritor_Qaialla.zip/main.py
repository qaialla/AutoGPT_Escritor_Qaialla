import openai
import os

# Carrega chave da OpenAI
openai.api_key = os.getenv("OPENAI_API_KEY")

def escrever_livro(titulo, estrutura):
    print(f"📘 Começando o livro: {titulo}")
    for i, capitulo in enumerate(estrutura, 1):
        prompt = f"Você é uma escritora best-seller. Escreva o capítulo {i}: {capitulo}, com linguagem sofisticada, emocional e estratégica."
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=1800
        )
        texto = response['choices'][0]['message']['content']
        print(f"\n\n=== Capítulo {i}: {capitulo} ===\n")
        print(texto)

# Título e estrutura exemplo
titulo_livro = "Você é uma marca e o mundo precisa conhecer você"
estrutura = [
    "Introdução: A importância de se posicionar como marca",
    "Como descobrir sua essência única",
    "Transformando sua história em autoridade",
    "Marca pessoal no mercado imobiliário de luxo",
    "Estética, presença e imagem: o trio magnético",
    "Influência e networking estratégico",
    "Branding digital poderoso com IA",
    "Como criar conteúdo que vende sua imagem",
    "Conectando sua marca ao público certo",
    "Encerramento: Seu nome é sua maior herança"
]

escrever_livro(titulo_livro, estrutura)
